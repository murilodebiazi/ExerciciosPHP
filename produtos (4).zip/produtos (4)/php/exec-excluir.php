<?php
    require_once("../php/conectar.php");

    if($_POST['confirmar'] === 'sim'){
        $id = $_POST['id'];
        $sql = "DELETE FROM cadastro WHERE id=$id";
        if(mysqli_query($conexao, $sql)){
            echo "Produto excluído com sucesso!<br>";
        }else{
            echo "Erro: " . mysqli_error($conexao);
        }
    }else{
        echo "Exclusão cancelada.<br>";
    }

    echo "<a = href='../php/listar.php'> Voltar à lista</a>";
    mysqli_close($conexao);
?>