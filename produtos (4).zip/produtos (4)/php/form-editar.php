<?php
    require_once("../php/conectar.php");
    $id = $_GET['id'];

    $resultado = mysqli_query($conexao, "SELECT * FROM cadastro WHERE id=$id");
    $linha = mysqli_fetch_assoc($resultado);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Produto</title>
</head>
<body>
    <h2>Editar Produto</h2>
    <form action="../php/exec-atualizar.php" method="post">
        <input type="hidden" name="id" value="<?php echo $Linha['id']; ?>">
        <label>Nome do Produto:</label>
        <input type="text" name="nome" value ="<?php echo $linha['nome']; ?>" required>
        <br><br>
        <button type="submit">Atualizar</button>
    </form>
        <br><br>
        <a href="../php/listar.php">Voltar</a>
</body>
</html>