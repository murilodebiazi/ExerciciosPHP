<?php
    $id = $_GET['id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmar Exclusão</title>
</head>
<body>
    <h2>Tem certeza que deseja excluir este produto?</h2>
    <form action="../php/exec-excluir.php" method="post">
        <input type="hidden" name="id" value="<?php echo $id; ?>">
        <button type="submit" name="confirmar" value="sim">Sim, excluir</button>
        <button type="submit" name="confirmar" value="nao"> Cancelar </button>
    </form>
</body>
</html>