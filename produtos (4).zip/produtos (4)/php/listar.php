<?php
    require_once("../php/conectar.php");
    $resultado = mysqli_query($conexao, "SELECT * FROM cadastro");
    echo "<h2>Atualizar/Excluir Produtos:</h2>";
    while($linha = mysqli_fetch_assoc($resultado)){
        echo "id: " . $linha['id'] . "-";
        echo $linha['nome']. "|";
        echo "<a href ='../php/form-editar.php?id=" . $linha['id']."'>Editar</a>|";
        echo "<a href ='../php/confirmar-excluir.php?id=" . $linha['id']. "'>Excluir</a>";
            echo"<br>";
    }
    mysqli_close($conexao);
?>