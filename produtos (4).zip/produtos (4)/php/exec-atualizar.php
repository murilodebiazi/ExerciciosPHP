<?php
    require_once("../php/conectar.php");
    $id = $_POST['id'];
    $nome = $_POST['nome'];

    $sql = "UPDATE cadastro SET nome = '$nome' WHERE id='$id'";

    if(mysqli_query($conexao, $sql)){
        echo "Produto atualizado com suceso!<br>";
        echo "<a href='../php/listar.php'>Voltar à lista</a>";
    }else{
        echo "Erro: " . mysqli_error($conexao);
    }
    mysqli_close($conexao);
?>